import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-del-student',
  templateUrl: './del-student.component.html',
  styleUrls: ['./del-student.component.css']
})
export class DelStudentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
