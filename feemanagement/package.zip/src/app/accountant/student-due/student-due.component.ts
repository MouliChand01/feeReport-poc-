import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-due',
  templateUrl: './student-due.component.html',
  styleUrls: ['./student-due.component.css']
})
export class StudentDueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
